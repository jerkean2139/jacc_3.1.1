# Whitelabel Relationship Analysis - Accept Blue vs TracerPay

## CONFIRMED: TracerPay is a Whitelabel of Accept Blue

### Evidence Summary:

#### 1. **Visual Design Identity**
- **Identical color schemes**: Both use the same blue gradient backgrounds and orange accent colors
- **Same graphics and icons**: Computer monitor illustrations, 3D security shields, dollar sign graphics, check processing icons
- **Identical layout structure**: Same page layouts, section arrangements, and design patterns
- **Same typography and styling**: Consistent fonts, spacing, and visual hierarchy

#### 2. **Content and Messaging**
- **Nearly identical copy**: Most text is word-for-word identical with only company name substitutions
- **Same value propositions**: Both emphasize interchange optimization, modern UX/UI, and white-label capabilities
- **Identical feature descriptions**: Features like "Set it and forget it" recurring payments use exact same language
- **Same customer pain points addressed**: Both target outdated, clunky gateway issues

#### 3. **Technical Features**
- **Identical feature set**: Both offer the same 9 core features
- **Same technical capabilities**: Interchange optimization, 3D Secure, ACH processing, etc.
- **Same integration approach**: Both mention similar processor and shopping cart integrations
- **Same security standards**: Both reference PCI Level 1 compliance

#### 4. **Business Model**
- **Both target ISOs**: Accept Blue explicitly mentions ISO partnerships, TracerPay uses similar language
- **White-label focus**: Accept Blue advertises as "exclusively white-labeled," TracerPay appears to be an example
- **Same market positioning**: Both position as modern alternatives to outdated gateways

#### 5. **Key Differences (Branding Only)**
- **Company names**: Accept Blue vs TracerPay
- **Logos**: accept.blue logo vs TP TRACER PAY logo
- **Domain names**: accept.blue vs tracerpay.com
- **Login terminology**: "ISO Login" vs "User Login"
- **CTA buttons**: "Partner today" vs "Schedule a Demo Today"

### Conclusion:
TracerPay is definitively a white-label implementation of the Accept Blue payment gateway platform. The evidence shows identical underlying technology, features, design, and messaging with only superficial branding changes. This confirms the user's observation and provides a clear example of Accept Blue's white-label business model in action.

