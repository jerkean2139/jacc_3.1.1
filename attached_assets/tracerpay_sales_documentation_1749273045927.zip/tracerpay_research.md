# Tracerpay Research Notes

## Initial Website Analysis - Tracerpay (tracerpay.com)

### Key Information:
- **URL**: https://tracerpay.com/
- **Logo**: "TP TRACER PAY" with green and blue design
- **Main Value Proposition**: "Seamless Payment Solutions Tailored for Your Business"
- **Tagline**: "Transform your payment processes with cutting-edge technology and dedicated service"
- **Secondary Message**: "Qualify transactions for best interchanges and increase profits with multiple advanced processing methods beyond Level III and 3D Secure"

### Navigation Structure:
- Home
- Features  
- Integrations
- Support
- User Login

### Visual Similarities to Accept Blue:
- **Identical blue color scheme** and gradient background
- **Same computer monitor graphic** with blue interface
- **Similar layout structure** and design elements
- **Similar messaging** about payment solutions
- **Same general aesthetic** and professional appearance

### Key Differences from Accept Blue:
- Different logo (TP vs accept.blue)
- "User Login" instead of "ISO Login"
- No "API" or "Blog" sections in navigation
- Different company branding but same underlying platform design
- "Schedule a Demo Today" CTA instead of "Partner today"

### Initial Whitelabel Confirmation:
The visual and structural similarities strongly suggest this is indeed a whitelabel version of the Accept Blue platform, with Tracerpay branding applied over the same underlying system and design framework.


## Tracerpay Features Analysis - IDENTICAL TO ACCEPT BLUE

### Confirmed Whitelabel Features (Same as Accept Blue):

1. **Interchange Optimization** 
   - "Interchange optimization has never been easier. The TracerPay gateway has automated the tedious and manual process of adding level 3 data to each transaction, giving merchants big savings on interchange rates without anyone lifting a finger."
   - **IDENTICAL FUNCTIONALITY** to Accept Blue's interchange optimization

2. **Modern UX/UI**
   - Same visual design and layout as Accept Blue
   - **IDENTICAL INTERFACE** design

3. **ACH/Check Processing**
   - "Looking to process a check instead of a credit card? No problem, our gateway has check processing built right into the virtual terminal, giving merchants even more ways of accepting payments."
   - **IDENTICAL COPY** to Accept Blue

4. **3D Secure**
   - "Eliminate chargebacks, increase approvals and reduce false declines. The TracerPay gateway supports 3D secure transactions, protecting merchants from the all-to-common 'friendly fraud' lurking everywhere."
   - **IDENTICAL FUNCTIONALITY** and nearly identical copy

5. **Recurring/Scheduled Payments**
   - "'Set it and forget it' has never been truer than on our virtual terminal. With various options to choose from, merchants can easily create subscription-based payments that fit their exact needs."
   - **IDENTICAL COPY** to Accept Blue

### Visual Evidence of Whitelabel Relationship:
- **Same color schemes** (blue and orange)
- **Identical graphics** and icons (3D shield, dollar sign graphics, check graphics)
- **Same layout structure** and design patterns
- **Nearly identical copy** with only "TracerPay" substituted for "accept.blue"
- **Same feature set** and functionality descriptions

